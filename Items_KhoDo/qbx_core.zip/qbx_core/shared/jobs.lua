---Job names must be lower case (top level table key)
---@type table<string, Job>
return {
    ['unemployed'] = {
        label = 'Voi Con',
        defaultDuty = true,
        offDutyPay = false,
        grades = {
            [0] = {
                name = 'Voi Thất Nghiệp',
                payment = 10
            },
        },
    },
    ['police'] = {
        label = 'Voi An Ninh',
        type = 'leo',
        defaultDuty = false,
        offDutyPay = false,
        grades = {
            [0] = {
                name = 'Học Viên',
                payment = 1000
            },
            [1] = {
                name = 'Hạ Sĩ',
                payment = 1600
            },
            [2] = {
                name = 'Thượng Sĩ',
                payment = 1700
            },
            [3] = {
                name = 'Trung Úy',
                payment = 1900
            },
            [4] = {
                name = 'Đại Úy',
                payment = 2000
            },
            [5] = {
                name = 'Trung Tá',
                payment = 2200
            },
            [6] = {
                name = 'Đại Tá',
                payment = 2300
            },
            [7] = {
                name = 'Thiếu Tướng',
                payment = 2500
            },
            [8] = {
                name = 'Phó Giám Đốc Cảnh Sát',
                payment = 2700,
            },
            [9] = {
                name = 'Giám Đốc Cảnh Sát',
                isboss = true,
                bankAuth = true,
                payment = 3000
            },
        },
    },

    ['ambulance'] = {
        label = 'Bác Sĩ Voi',
        type = 'ems',
        defaultDuty = false,
        offDutyPay = false,
        grades = {
            [0] = {
                name = 'Voi Học Viên',
                payment = 1900
            },
            [1] = {
                name = 'Bác Sĩ',
                payment = 2000
            },
            [2] = {
                name = 'Chuyên Khoa',
                payment = 2200,
                isboss = true,
            },
            [3] = {
                name = 'Trưởng Khoa',
                payment = 2300,
                isboss = true,
            },
            [4] = {
                name = 'Thư Ký',
                payment = 2500,
            },
            [5] = {
                name = 'Phó Giám Đốc Bác Sĩ',
                isboss = true,
                payment = 2600
            },
            [6] = {
                name = 'Giám Đốc Bác Sĩ',
                isboss = true,
                bankAuth = true,
                payment = 2600
            },
        },
    },
    ['cardealer'] = {
        label = 'Voi Bán Xe',
        defaultDuty = false,
        offDutyPay = false,
        grades = {
            [0] = {
                name = 'Nhân Viên',
                payment = 1300
            },
            [1] = {
                name = 'Quản Lí Nhân Viên',
                payment = 1350
            },
            [2] = {
                name = 'Thư Ký',
                payment = 1400
            },
            [3] = {
                name = 'Phó Giám Đốc',
                isboss = true,
                bankAuth = true,
                payment = 1500
            },
            [4] = {
                name = 'Giám Đốc',
                isboss = true,
                bankAuth = true,
                payment = 1500
            },
        },
    },     
    ['mechanic'] = {
        label = 'Mechanic',
        type = 'mechanic',
        defaultDuty = true,
        offDutyPay = false,
        grades = {
            [0] = {
                name = 'NHÂN VIÊN',
                payment = 1500
            },
            [1] = {
                name = 'PHÓ GIÁM ĐỐC',
                payment = 1700
            },
            [2] = {
                name = 'GIÁM ĐỐC',
                isboss = true,
                bankAuth = true,
                payment = 1700
            },
        },
    },
    ['ttc'] = {
        label = 'Tòa Thị Chính',
        type = 'ttc',
        defaultDuty = true,
        offDutyPay = false,
        grades = {
            [0] = {
                name = 'Support',
                payment = 0
            },
            [1] = {
                name = 'Game Master',
                payment = 0
            },
        },
    },
}
